# PH MUSIC PLAY

Primeira versão funcional do player Android.

## Funcionalidades
- Seleção de músicas por armazenamento do celular/cartão e por provedores do Android, incluindo Google Drive quando disponível no seletor.
- Reprodução de áudio local.
- Play/Pause, anterior, próxima e aleatório.
- Barra de progresso e volume.
- Lista de músicas selecionadas.
- Favoritas persistentes para a música atual.
- Logo original do usuário usada no topo.

## Observação
O projeto está pronto para ser aberto no Android Studio e compilado como APK. Esta sessão não possui o Gradle/Android SDK necessário para executar a compilação local do APK aqui.
