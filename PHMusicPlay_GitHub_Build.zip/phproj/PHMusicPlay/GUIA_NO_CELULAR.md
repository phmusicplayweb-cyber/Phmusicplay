# PH MUSIC PLAY — gerar APK pelo celular

1. Crie/abra um repositório no GitHub pelo navegador do celular.
2. Envie todos os arquivos e pastas deste projeto, mantendo a pasta `phproj/PHMusicPlay`.
3. Entre em Actions.
4. Abra `Build PH MUSIC PLAY APK`.
5. Toque em `Run workflow`.
6. Quando terminar, abra a execução concluída e baixe o artefato `PH-MUSIC-PLAY-debug`.
7. Extraia o arquivo e instale `app-debug.apk` no Android.

Não é necessário Android Studio no celular. O GitHub faz a compilação na nuvem.
