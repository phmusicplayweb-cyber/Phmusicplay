package com.phmusicplay.app;

import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.*;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO = 10;
    private static final int BG = Color.rgb(8, 8, 28);
    private static final int CARD = Color.rgb(13, 10, 27);
    private static final int WHITE = Color.WHITE;
    private static final int CYAN = Color.rgb(45, 210, 255);
    private static final int PINK = Color.rgb(255, 80, 220);
    private static final int YELLOW = Color.rgb(255, 210, 30);

    private LinearLayout list;
    private TextView title, artist, time, empty;
    private ImageButton play, favorite;
    private SeekBar progress, volume;
    private MediaPlayer player;
    private final ArrayList<Uri> songs = new ArrayList<>();
    private int index = -1;
    private boolean shuffle = false;
    private final Random random = new Random();
    private final Handler handler = new Handler();
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (player != null) {
                int pos = player.getCurrentPosition();
                progress.setProgress(pos);
                time.setText(format(pos) + " / " + format(player.getDuration()));
                handler.postDelayed(this, 500);
            }
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
    }

    private TextView text(String value, float size) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(WHITE);
        t.setTextSize(size);
        t.setPadding(14, 8, 14, 8);
        return t;
    }

    private Button action(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(WHITE);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(14, 12, 14, 12);
        c.setBackgroundColor(CARD);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 8, 0, 8);
        c.setLayoutParams(p);
        return c;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(10, 8, 10, 18);
        scroll.addView(root);
        setContentView(scroll);

        ImageView logo = new ImageView(this);
        logo.setImageResource(com.phmusicplay.app.R.drawable.ph_logo_original);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        logo.setAdjustViewBounds(true);
        root.addView(logo, new LinearLayout.LayoutParams(-1, 300));

        LinearLayout now = card();
        LinearLayout nowRow = new LinearLayout(this);
        nowRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView note = text("♫", 58);
        note.setTextColor(PINK);
        nowRow.addView(note, new LinearLayout.LayoutParams(90, 100));
        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        TextView label = text("TOCANDO AGORA", 14);
        label.setTextColor(PINK);
        info.addView(label);
        title = text("Nenhuma música selecionada", 21);
        info.addView(title);
        artist = text("Escolha uma música abaixo", 14);
        artist.setTextColor(CYAN);
        info.addView(artist);
        time = text("00:00 / 00:00", 12);
        info.addView(time);
        nowRow.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
        favorite = new ImageButton(this);
        favorite.setImageResource(android.R.drawable.btn_star_big_off);
        favorite.setBackgroundColor(Color.TRANSPARENT);
        favorite.setOnClickListener(v -> toggleFavorite());
        nowRow.addView(favorite, new LinearLayout.LayoutParams(58, 58));
        now.addView(nowRow);
        progress = new SeekBar(this);
        now.addView(progress);
        root.addView(now);

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        Button shuffleBtn = action("🔀\nALEATÓRIO");
        Button prev = action("⏮");
        play = new ImageButton(this);
        play.setImageResource(android.R.drawable.ic_media_play);
        play.setBackgroundColor(Color.TRANSPARENT);
        Button next = action("⏭");
        controls.addView(shuffleBtn, new LinearLayout.LayoutParams(0, 76, 1));
        controls.addView(prev, new LinearLayout.LayoutParams(0, 76, 0.8f));
        controls.addView(play, new LinearLayout.LayoutParams(0, 76, 1));
        controls.addView(next, new LinearLayout.LayoutParams(0, 76, 0.8f));
        root.addView(controls);

        TextView volumeLabel = text("VOLUME", 12);
        volumeLabel.setTextColor(CYAN);
        root.addView(volumeLabel);
        volume = new SeekBar(this);
        volume.setMax(100);
        volume.setProgress(80);
        root.addView(volume);

        shuffleBtn.setOnClickListener(v -> {
            shuffle = !shuffle;
            shuffleBtn.setText(shuffle ? "🔀\nALEATÓRIO ON" : "🔀\nALEATÓRIO");
        });
        prev.setOnClickListener(v -> previous());
        next.setOnClickListener(v -> next());
        play.setOnClickListener(v -> togglePlay());
        progress.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar s) {}
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {}
            public void onStopTrackingTouch(SeekBar s) { if (player != null) player.seekTo(s.getProgress()); }
        });
        volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) {}
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (player != null) { float x = p / 100f; player.setVolume(x, x); }
            }
        });

        LinearLayout sources = new LinearLayout(this);
        Button memory = action("📁  MÚSICAS DO\nCARTÃO DE MEMÓRIA");
        Button drive = action("☁  MÚSICAS DO\nGOOGLE DRIVE");
        sources.addView(memory, new LinearLayout.LayoutParams(0, 100, 1));
        sources.addView(drive, new LinearLayout.LayoutParams(0, 100, 1));
        root.addView(sources);
        memory.setOnClickListener(v -> pickAudio());
        drive.setOnClickListener(v -> pickAudio());

        TextView listTitle = text("MINHAS MÚSICAS", 18);
        listTitle.setTextColor(CYAN);
        root.addView(listTitle);
        empty = text("Nenhuma música carregada. Toque em uma das pastas acima.", 14);
        empty.setTextColor(Color.LTGRAY);
        root.addView(empty);
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        LinearLayout bottom = new LinearLayout(this);
        Button playlists = action("🎵  PLAYLISTS");
        Button favorites = action("♡  FAVORITAS");
        bottom.addView(playlists, new LinearLayout.LayoutParams(0, 64, 1));
        bottom.addView(favorites, new LinearLayout.LayoutParams(0, 64, 1));
        root.addView(bottom);
        playlists.setOnClickListener(v -> Toast.makeText(this, "Playlists: em desenvolvimento nesta versão.", Toast.LENGTH_SHORT).show());
        favorites.setOnClickListener(v -> Toast.makeText(this, "Favoritas: use o coração da música atual.", Toast.LENGTH_SHORT).show());
    }

    private void pickAudio() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("audio/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, PICK_AUDIO);
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request != PICK_AUDIO || result != RESULT_OK || data == null) return;
        songs.clear();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) addUri(data.getClipData().getItemAt(i).getUri());
        } else if (data.getData() != null) addUri(data.getData());
        refreshList();
        if (!songs.isEmpty()) load(0);
    }

    private void addUri(Uri uri) {
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
        if (!songs.contains(uri)) songs.add(uri);
    }

    private void refreshList() {
        list.removeAllViews();
        empty.setVisibility(songs.isEmpty() ? View.VISIBLE : View.GONE);
        for (int i = 0; i < songs.size(); i++) {
            final int n = i;
            String name = displayName(songs.get(i));
            Button row = action(String.format(Locale.getDefault(), "%02d   🎵  %s   ▶", i + 1, name));
            row.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
            row.setOnClickListener(v -> load(n));
            list.addView(row, new LinearLayout.LayoutParams(-1, 58));
        }
    }

    private String displayName(Uri uri) {
        String result = null;
        try (android.database.Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) result = c.getString(0);
        } catch (Exception ignored) {}
        return result != null ? result : String.valueOf(uri.getLastPathSegment());
    }

    private void load(int n) {
        if (songs.isEmpty()) return;
        index = Math.max(0, Math.min(n, songs.size() - 1));
        try {
            releasePlayer();
            player = MediaPlayer.create(this, songs.get(index));
            if (player == null) throw new IllegalStateException();
            player.setOnCompletionListener(v -> next());
            player.setVolume(volume.getProgress() / 100f, volume.getProgress() / 100f);
            progress.setMax(player.getDuration());
            title.setText(metadata(songs.get(index), MediaMetadataRetriever.METADATA_KEY_TITLE, displayName(songs.get(index))));
            artist.setText(metadata(songs.get(index), MediaMetadataRetriever.METADATA_KEY_ARTIST, "PH MUSIC PLAY"));
            player.start();
            play.setImageResource(android.R.drawable.ic_media_pause);
            handler.removeCallbacks(ticker);
            handler.post(ticker);
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível reproduzir esta música.", Toast.LENGTH_SHORT).show();
        }
    }

    private String metadata(Uri uri, int key, String fallback) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try { r.setDataSource(this, uri); String v = r.extractMetadata(key); return v == null || v.trim().isEmpty() ? fallback : v; }
        catch (Exception e) { return fallback; }
        finally { try { r.release(); } catch (Exception ignored) {} }
    }

    private void togglePlay() {
        if (player == null) { if (!songs.isEmpty()) load(0); return; }
        if (player.isPlaying()) { player.pause(); play.setImageResource(android.R.drawable.ic_media_play); }
        else { player.start(); play.setImageResource(android.R.drawable.ic_media_pause); }
    }

    private void next() {
        if (songs.isEmpty()) return;
        int n = shuffle ? random.nextInt(songs.size()) : (index + 1) % songs.size();
        load(n);
    }

    private void previous() {
        if (songs.isEmpty()) return;
        load((index - 1 + songs.size()) % songs.size());
    }

    private void toggleFavorite() {
        if (index < 0 || index >= songs.size()) return;
        String key = songs.get(index).toString();
        android.content.SharedPreferences p = getSharedPreferences("favorites", MODE_PRIVATE);
        boolean current = p.getBoolean(key, false);
        p.edit().putBoolean(key, !current).apply();
        favorite.setImageResource(!current ? android.R.drawable.btn_star_big_on : android.R.drawable.btn_star_big_off);
        Toast.makeText(this, !current ? "Adicionada às favoritas." : "Removida das favoritas.", Toast.LENGTH_SHORT).show();
    }

    private String format(int ms) {
        int seconds = Math.max(0, ms) / 1000;
        return String.format(Locale.getDefault(), "%02d:%02d", seconds / 60, seconds % 60);
    }

    private void releasePlayer() {
        handler.removeCallbacks(ticker);
        if (player != null) { try { player.stop(); } catch (Exception ignored) {} player.release(); player = null; }
    }

    @Override protected void onDestroy() { releasePlayer(); super.onDestroy(); }
}
