# PH MUSIC PLAY — Projeto

## Tela principal aprovada
- Manter a logo original do usuário sem redesenhar.
- Visual neon sobre fundo escuro.
- Player central com música atual, capa, artista e progresso.
- Controles: anterior, play/pause, próxima e aleatório.
- Controle de volume.
- Botão: Músicas do cartão de memória.
- Botão: Músicas do Google Drive.
- Lista: Minhas músicas.
- Favoritas/Playlists.

## Funções que NÃO devem aparecer
- Equalizador
- Configurações
- Rádio ao vivo
- Microfone
- Programação da semana
- Divulgação de trabalhos

## Próxima etapa
Integrar a imagem/logo original fornecida pelo usuário e implementar a seleção e reprodução das músicas no Android.
